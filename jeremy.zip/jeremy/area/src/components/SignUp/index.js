import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';

import FacebookLogin from "react-facebook-login";

import { withFirebase } from '../Firebase';
import * as ROUTES from '../../constants/routes';

import { withGlobalState } from 'react-globally'

//import '../SignIn/SignIn.css';

import "../SignIn/bootstrap.min.css"
import "../SignIn/st.css"
import "../SignIn/iofrm-theme4.css"
import img from "../../images/graphic1.svg"

const SignUpPage = () => (
  <div>
    <SignUpForm />
  </div>
);

const INITIAL_STATE = {
  username: '',
  firstname: '',
  lastname: '',
  email: '',
  password: '',
  error: null,
};

class SignUpFormBase extends Component {
  constructor(props) {
    super(props);

    this.state = { ...INITIAL_STATE };
  }

  facebook_login(response) {
    console.log("response facebook : ",response);
    this.setState({
      username: response.name,
      email: response.email,
      firstname: '',
      lastname: '',
      password: '',
    })
    this.props.setGlobalState({
        facebook_oauth: response,
    });
  }

  google_login() {
    
  }

  linkedin_login() {
    
  }

  onSubmit = event => {
    const { username, email, password, firstname, lastname } = this.state;

    event.preventDefault();
    var jsonObject = {
      'username': username,
      'password': password,
      'emailAdress': email,
      'firstName': firstname,
      'lastName': lastname
    }
    var url = "http://localhost:8080/users/register"//"http://35.188.140.35:8080/users/register";
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
      body: JSON.stringify(jsonObject),
    })
    .then((res) => {
      console.log(res);
      if (res.ok === true) {
        this.props.history.push(ROUTES.HOME);
      } else {
        this.setState({
          error: "Error: Check your form"
        });
      }
    })
    .then((error) => {
      console.log(error);
    })
  };

  onChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  };

  render() {
    const {error} = this.state;
    return (
      <div className="container-fluid">
        <div className="website-logo">
          <div className="logo logo-area">
              <img className="logo-size" alt="logo"/>
          </div>
        </div>
        <div className="background-sign-page"></div>
        <div className="row">
          <img className="image-groupe-signin" src={img} alt=""/>
            <div className="form-holder">
                <div className="form-content">
                    <div className="form-items">
                        <h3>Facilitez vos tâches de travail en connectant vos services entre eux.</h3>
                        <p>Avec Workinspot, regroupez l'essentiel et gagnez du temps.</p>
                        <div className="page-links">
                            <a href="/">Se connecter</a><a href="signup" className="active">S'inscrire</a>
                        </div>
                        <input onChange={this.onChange} className="form-control" type="text" name="firstname" value={this.state.firstname} placeholder="First Name" required/>
                        <input onChange={this.onChange} className="form-control" type="text" name="lastname" value={this.state.lastname} placeholder="Last Name" required/>
                        <input onChange={this.onChange} className="form-control" type="text" name="username" value={this.state.username} placeholder="User Name" required/>
                        <input onChange={this.onChange} className="form-control" type="email" name="email" value={this.state.email} placeholder="E-mail Address" required/>
                        <input onChange={this.onChange} className="form-control" type="password" name="password" value={this.state.password} placeholder="Password" required/>
                        <div className="form-button">
                            <button id="submit" onClick={this.onSubmit.bind(this)} className="ibtn">S'inscrire</button>
                        </div>
                        <p style={{color: "red"}}>{error}</p>
                        <div className="other-links">
                            <span>Se connecter via</span>
                            <FacebookLogin
                              className="facebook_sign_in"
                              appId="211013790052168"
                              autoLoad={false}
                              fields="name,email,picture"
                              textButton="Facebook"
                              cssClass=""
                              callback={this.facebook_login.bind(this)} />
                            <a href="home" onClick={this.google_login}>Google</a>
                            <a href="home" onClick={this.linkedin_login}>Linkedin</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    );
  }
}

const SignUpLink = () => (
  <p>
    Don't have an account? <Link to={ROUTES.SIGN_UP}>Sign Up</Link>
  </p>
);

const SignUpForm = withGlobalState(withRouter(withFirebase(SignUpFormBase)));

export default SignUpPage;

export { SignUpForm, SignUpLink };
