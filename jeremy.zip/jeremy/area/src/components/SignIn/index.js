import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { compose } from 'recompose';

import FacebookLogin from "react-facebook-login";

//import { SignUpLink } from '../SignUp';
//import { PasswordForgetLink } from '../PasswordForget';
import { withFirebase } from '../Firebase';
import * as ROUTES from '../../constants/routes';
import "./bootstrap.min.css"
import "./st.css"
import "./iofrm-theme4.css"
import img from "../../images/graphic1.svg"

import { withGlobalState } from 'react-globally'

const SignInPage = () => (
    <SignInForm />    
);

const INITIAL_STATE = {
  username: '',
  password: '',
  error: null,
};

class SignInFormBase extends Component {
  constructor(props) {
    super(props);

    this.state = { ...INITIAL_STATE }
    console.log("props signin : ");
    console.log(props);
  }

  facebook_login(response) {
    console.log("response facebook : ",response);
    this.setState({
      username: response.name,
      password: '',
    })
    this.props.setGlobalState({
        facebook_oauth: response,
    });
  }

  google_login() {
    
  }

  linkedin_login() {
    
  }

  onSubmit() {
    const { username, password } = this.state;
    var jsonObject = {
      'username': username,
      'password': password
    }
    fetch("http://localhost:8080/users/authenticate", { //"http://35.188.140.35:8080/users/authenticate", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
      body: JSON.stringify(jsonObject),
    })
    .then((res) => {
      var p = this.props;
      var t = this;
      res.json().then(function(parsedJson) {
        console.log("Authenticate success", parsedJson);
        p.setGlobalState({
          user: parsedJson,
        }, function() {
          if (!parsedJson || parsedJson.message) {
            t.setState({
              error: parsedJson.message
            });
          } else {
            p.history.push(ROUTES.HOME);
          }
        });
      })
    })
    .then((error) => {
      console.log(error);
    })
  };

  onChange = event => {
    this.setState({ [event.target.name]: event.target.value });

  };

  render() {
    const { error } = this.state;

    //const isInvalid = password === '' || email === '';

    return (
      <div className="container-fluid">
        <div className="website-logo">
          <div className="logo logo-area">
              <img alt="logo" className="logo-size"/>
          </div>
        </div>
        <div className="background-sign-page"></div>
        <div className="row">
            <img className="image-groupe-signin" src={img} alt=""/>
            <div className="form-holder">
                <div className="form-content">
                    <div className="form-items">
                        <h3>Facilitez vos tâches de travail en connectant vos services entre eux.</h3>
                        <p>Avec Workinspot, regroupez l'essentiel et gagnez du temps.</p>
                        <div className="page-links">
                            <a href="signin" className="active">Se connecter</a><a href="signup">S'inscrire</a>
                        </div>
                        <input onChange={this.onChange} value={this.state.username} id="login_username" className="form-control" type="text" name="username" placeholder="Username" required/>
                        <input onChange={this.onChange} value={this.state.password} id="login_password" className="form-control" type="password" name="password" placeholder="password" required/>
                        <div className="form-button">
                            <button id="submit" onClick={this.onSubmit.bind(this)} className="ibtn">Se connecter</button>
                        </div>
                        <p style={{color: "red"}}>{error}</p>
                        <div className="other-links">
                            <span>Se connecter via</span>
                            <FacebookLogin
                              className="facebook_sign_in"
                              appId="211013790052168"
                              autoLoad={false}
                              fields="name,email,picture"
                              textButton="Facebook"
                              cssClass=""
                              callback={this.facebook_login.bind(this)} />
                            <a href="home" onClick={this.google_login}>Google</a>
                            <a href="home" onClick={this.linkedin_login}>Linkedin</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    );
  }
}

const SignInForm = compose(
  withRouter,
  withFirebase,
  withGlobalState,
)(SignInFormBase);

export default (SignInPage);

export { SignInForm };
