import React, {Component} from 'react';

import { withRouter } from 'react-router-dom';
import { compose } from 'recompose';
import { withGlobalState } from 'react-globally';
import * as ROUTES from '../../constants/routes';

const style = {
  "borderRadius": "20px"
} 

const SignOutButton = () => (
  <SignOut/>
);

class SignOutBase extends Component {
  deconnexion() {
    const p = this.props;
    p.setGlobalState({
      user: null,
    }, function() {
      p.history.push(ROUTES.SIGN_IN)
    })
  }

  render() {
    return (
      <div>
        <button style={style} type="button" onClick={this.deconnexion.bind(this)}>
          Déconnexion
        </button>
      </div>
    );
  }
};

const SignOut = compose(
  withGlobalState,
  withRouter,
  )(SignOutBase);

export { SignOut }

export default withGlobalState(withRouter(SignOutButton));
