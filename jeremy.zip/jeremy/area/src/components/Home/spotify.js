import React, { Component } from 'react';

import SpotifyLogin from "react-spotify-login";

import { withGlobalState } from 'react-globally'

import spotifyIcon from "../../images/spotify-icon.png"

import "./home.css"

class SpotifyBase extends Component {
    onSuccess(response) {
        console.log(response);
        this.props.setGlobalState({
            spotify_oauth: response,
        });
        var jsonObject = {
            'userId': this.props.globalState.user._id,
            'type': "spotify",
            'value': response.access_token
          }
          fetch("http://localhost:8080/tokens/update", { //"http://35.188.140.35:8080/users/authenticate", {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer '+ this.props.globalState.user.token,
            },
            mode: 'cors',
            body: JSON.stringify(jsonObject),
          })
    }
    onFailure(response) {
        console.log(response);
    }

    render() {
        return (
            <div className="case">
            {
                this.props.globalState.spotify_oauth ? (
                    <div>
                        <img style={{blockSize: "50px"}} src={spotifyIcon} alt="Spotify"/>
                        <p>Vous étes connecté à Spotify</p>
                    </div>
                ) : (
                    <SpotifyLogin clientId={"e3258cf99bc14facbb41ab0f7229de7b"}
                        redirectUri={"http://localhost:3000/home"}
                        scope={"user-read-currently-playing",
                                "user-read-playback-state"}
                        onSuccess={this.onSuccess.bind(this)}
                        buttonText={"Spotify"}
                        onFailure={this.onFailure}/>
                )
            }
            </div>
        )
    }
}

export default withGlobalState(SpotifyBase)