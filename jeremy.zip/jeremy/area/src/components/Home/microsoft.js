import React, { Component } from 'react';

import MicrosoftLogin from "react-microsoft-login";

import { withGlobalState } from 'react-globally'

import microsoftIcon from "../../images/microsoft-icon.png"

import "./home.css"

class MicrosoftBase extends Component {
    constructor(props) {
        super(props);
        this.state = {
            microsoft_oauth: null,
        }
    }
    render() {
        const authHandler = (err, data) => {
            this.props.setGlobalState({
                microsoft_oauth: data.authResponseWithAccessToken,
            });
            this.setState({
              microsoft_oauth: data.authResponseWithAccessToken,
            });
        };
        return (
            <div className={"case"}>
            {
                this.state.microsoft_oauth ? (
                    <div>
                        <img src={microsoftIcon} style={{blockSize: "100px"}} alt="Microsoft"/>
                        <p>Vous étes connecté à Microsoft</p>
                    </div>
                ) : (
                    <MicrosoftLogin clientId={'ba8f14c1-3ba3-4677-9314-0ed205395a6d'} authCallback={authHandler} />
                )
            }
            </div>
        )
    }
}

export default withGlobalState(MicrosoftBase)