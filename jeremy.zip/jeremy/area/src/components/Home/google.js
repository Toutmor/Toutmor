import React, { Component } from 'react';

import GoogleLogin from 'react-google-login';

import { withGlobalState } from 'react-globally'

import googleIcon from "../../images/google-icon.png"

import "./home.css"

class GoogleBase extends Component {
    constructor(props) {
        super(props);
        this.state = {
            google_oauth: null,
        }
    }

    responseGoogle(response) {
        this.props.setGlobalState({
            google_oauth: response,
        });
    }

    render() {
        const {google_oauth} = this.props.globalState;
        return (
            <div className="case">
            {
                google_oauth ? (
                    <div>
                        <img style={{blockSize: "50px", marginRight: "30px"}} src={googleIcon} alt="Google"/>
                <p>{console.log(this.props.globalState)}</p>
                    </div>
                ) : (
                    <GoogleLogin
                        clientId="550100731361-0j38ermvht3n99p2efdcukcvpbhmbq6n.apps.googleusercontent.com"
                        buttonText="Login"
                        onSuccess={this.responseGoogle.bind(this)}
                        onFailure={this.responseGoogle.bind(this)}
                        cookiePolicy={'single_host_origin'}
                    />
                )
            }
            </div>
        )
    }
}

export default withGlobalState(GoogleBase)