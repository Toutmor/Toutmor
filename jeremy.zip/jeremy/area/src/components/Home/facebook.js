import React, { Component } from 'react';

import FacebookLogin from "react-facebook-login";

import { withGlobalState } from 'react-globally'

import "./home.css"

import facebookIcon from "../../images/facebook-icon.png"

class FacebookBase extends Component {
    constructor(props) {
        super(props);
        this.state = {
            facebook_oauth: null,
        }
    }

    responseFacebook(response) {
        console.log("response facebook : ",response);
        this.props.setGlobalState({
            facebook_oauth: response,
        });
    }

    render() {
        const { facebook_oauth } = this.props.globalState;
        return (
            <div className="case">
            {
                facebook_oauth ? (
                    <div>
                        <img src={facebookIcon} style={{blockSize: "50px"}} alt="Facebook"/>
                        <img src={facebook_oauth.picture.data.url} alt="Profil Facebook"/>
                        <p>Vous étes connecté à Facebook</p>
                    </div>
                ) : (
                    <div>
                        <FacebookLogin
                            cssClass="fb connect"
                            appId="211013790052168"
                            autoLoad={false}
                            fields="name,email,picture"
                            callback={this.responseFacebook.bind(this)} />
                    </div>
                )
            }
            </div>
        )
    }
}

export default withGlobalState(FacebookBase)