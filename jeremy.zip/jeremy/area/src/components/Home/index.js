import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { compose } from 'recompose';

import Select from 'react-select';
import { AgGridReact } from 'ag-grid-react';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';


import MicrosoftCase from "./microsoft";
import SpotifyCase from "./spotify"
import GoogleCase from "./google"
import Notification from "./notification"
import FacebookCase from './facebook';

import { withGlobalState } from 'react-globally'

import img_fleche from '../../images/fleche.png'

import * as ROUTES from '../../constants/routes';

import "./home.css"

const HomePage = () => (
  <div>
    <Connecteurs/>
  </div>
);

class ConnecteursBase extends Component {
  constructor(props) {
    super(props);

    this.state = {
      list_a: [
        { value: 'instagram', label: 'Instagram' },
        { value: 'trello', label: 'Trello' },
        { value: 'linkedin', label: 'Linkedin' },
      ],
      list_rea: [
        { value: 'microsoft', label: 'Microsoft' },
        { value: 'facebook', label: 'Facebook' },
        { value: 'google', label: 'Google' },
      ],
      selected_list_a: '',
      selected_list_rea: '',
      list: [],
      areaGridApi: null,
      areaGrid: {
        columnDefs: [
          { headerName: "Action", field: "a"},
          { headerName: "Reaction", field: "rea"},
          {
            headerName: "Activer",
            field: "activate",
            cellRenderer: function(params) { 
              //console.log(params);
              var input = document.createElement('input');
              input.type="checkbox";
              input.checked=params.value;
              input.addEventListener('click', function (event) {
                  params.value=!params.value;
                  params.node.data.activate = params.value;
              });
              return input;
            }
          },
          { headerName: "id", field: "id", width: 100},
          {
            headerName: "Supprimer",
            field: 'suppr',
            cellRenderer: function(params) { 
              //console.log(params);
              var input = document.createElement('button');
              input.checked=params.value;
              input.addEventListener('click', function (event) {
                  params.api.updateRowData({ remove: [params.data] })
              });
              return input;
            }
          },
        ],
        rowData: [
          {
            a: "facebook",
            rea: "trello",
            activate: true,
            id: 1,
          },{
            a: "instag",
            rea: "google",
            activate: false,
            id: 2,
          },
        ],
      },
      select: false,
    };
  }

  componentDidMount() {
    if (!this.props.globalState.user || this.props.globalState.user.message)
      this.props.history.push(ROUTES.SIGN_IN);
      console.log(this.props.globalState.user._id);
  }

  handleChange_list_a(selected_list_a) {
    this.setState(
      { selected_list_a },
      () => console.log('Option selected:', this.state.selected_list_a)
    );
  }

  handleChange_list_rea(selected_list_rea) {
    this.setState(
      { selected_list_rea },
      () => console.log(`Option selected:`, this.state.selected_list_rea)
    );
  }

  button() {
    console.log("props dans connecteur : ",this.props);
  }

  addToListe() {
    if (!this.state.selected_list_a.value || !this.state.selected_list_rea.value)
      return;
    var area = {
      a: this.state.selected_list_a.value,
      rea: this.state.selected_list_rea.value,
      activate: true,
      id: this.state.areaGrid.rowData.length + 1,
    };

    this.state.areaGridApi.updateRowData({ add: [area] })

  }

  onSelectionChanged(data) {
    this.setState({
      select: this.state.select ? false : true,
    });
  }

  onGridReady = params => {
    params.api.forEachNode((node, index) => {
      this.state.areaGrid.rowData.forEach((value, ind) => {
        if (value.id === node.data.id && value.activate === true) {
          node.setSelected(true);
        }
      });
    });

    this.setState({
      areaGridApi: params.api
    })
  }

  sendArea() {
    const { rowData } = this.state.areaGrid;
    console.log(rowData);
    /*var jsonObject = {
      'area_list': rowData,
    }
    fetch("http://localhost:8080/users/authenticate", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'cors',
      body: JSON.stringify(jsonObject),
    })
    .then((res) => {
      var p = this.props;
      res.json().then(function(parsedJson) {
        console.log("Authenticate success", parsedJson);
        p.setGlobalState({
          user: parsedJson,
        }, function() {
            event.preventDefault();
            p.history.push(ROUTES.HOME);
        });
      })
    })
    .then((error) => {
      console.log(error);
    })*/
  }

  render() {
    const {list_a, list_rea, selected_list_a, selected_list_rea, areaGrid} = this.state;
    return (
      <div className="connecteurs">
        <h1>
          Bienvenue !
        </h1>
        <Notification/>
        <MicrosoftCase/>
        <SpotifyCase/>
        <GoogleCase/>
        <FacebookCase/>
        <button onClick={this.button.bind(this)}>Get State Global</button>
        <h1>Connectez-vous aux services</h1>
        <Select
          className="select_list_a"
          value={selected_list_a}
          onChange={this.handleChange_list_a.bind(this)}
          options={list_a}
          placeholder="Action"
        />
        <img style={{textAlign: "center", blockSize: "50px", marginTop: "10px", marginBottom: "10px", marginLeft: "40%"}} src={img_fleche} alt="fleche"/>
        <Select
          className="select_list_a"
          value={selected_list_rea}
          onChange={this.handleChange_list_rea.bind(this)}
          options={list_rea}
          placeholder="Reaction"
        />
        <button onClick={this.addToListe.bind(this)}>Ajouter</button>
        <div className="ag-theme-balham" style={ {height: '200px', width: '800px'} }>
          <AgGridReact
              rowSelection="multiple"
              onSelectionChanged={this.onSelectionChanged.bind(this)}
              checkboxSelection={true}
              columnDefs={areaGrid.columnDefs}
              rowData={areaGrid.rowData}
              onGridReady={this.onGridReady}>
          </AgGridReact>
        </div>
        <button onClick={this.sendArea.bind(this)}>Sauvegarder</button>
      </div>
    );
  }
}

const Connecteurs = compose(
  withGlobalState,
  withRouter,
  )(ConnecteursBase);

export default (HomePage);

export { Connecteurs }
