import React, { Component } from 'react';

import TrelloClient from 'react-trello-client'

import "./home.css"

class TrelloBase extends Component {
    constructor(props) {
        super(props);
        this.state = {
            trello_oauth: null,
        }
    }
    render() {
        return (
            <div className="case">
            {
                this.state.trello_oauth ? (
                    <div></div>
                ) : (
                    <TrelloClient
                    apiKey="f415cd0a0e4f3af44061eeb9d347441f" // Get the API key from https://trello.com/app-key/
                    clientVersion={1} // number: {1}, {2}, {3}
                    apiEndpoint="https://api.trello.com" // string: "https://api.trello.com"
                    authEndpoint="https://trello.com" // string: "https://trello.com"
                    intentEndpoint="https://trello.com" // string: "https://trello.com"
                    authorizeName="AREA" // string: "React Trello Client"
                    authorizeType="popup" // string: popup | redirect
                    authorizePersist={true}
                    authorizeInteractive={true}
                    authorizeScopeRead={false} // boolean: {true} | {false}
                    authorizeScopeWrite={true} // boolean: {true} | {false}
                    authorizeScopeAccount={true} // boolean: {true} | {false}
                    authorizeExpiration="never" // string: "1hour", "1day", "30days" | "never"
                    authorizeOnSuccess={(resp) => {
                        console.log(resp);
                        console.log('Login successful!')
                        }
                    } // function: {() => console.log('Login successful!')}
                    authorizeOnError={() => console.log('Login error!')} // function: {() => console.log('Login error!')}
                    autoAuthorize={false} // boolean: {true} | {false}
                    authorizeButton={true} // boolean: {true} | {false}
                    buttonStyle="flat" // string: "metamorph" | "flat"
                    buttonColor="light" // string: "green" | "grayish-blue" | "light"
                    buttonText="Sign in with Trello" // string: "Login with Trello"
                    />
                )
                }
            </div>
        )
    }
}

export default TrelloBase