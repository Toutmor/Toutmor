import React, { Component } from 'react';

import notif_icon from "../../images/notif-icon.png"

import "./home.css"

class NotificationBase extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showNotifVolet: false,
            messages: null,
        }

        this.showVolet = this.showVolet.bind(this);
        this.closeVolet = this.closeVolet.bind(this);
    }

    closeVolet(event) {
        event.preventDefault();
    
        this.setState({showNotifVolet: false}, () => {
          document.removeEventListener('click', this.closeVolet)
        })
    }

    showVolet(event) {
        event.preventDefault();
        
        this.setState({ showNotifVolet: true }, () => {
            document.addEventListener('click', this.closeVolet);
        });
    }

    render() {
        return (
            <div>
                <button className="btn-notif" onClick={this.showVolet}>
                    <img className="img-notif" src={notif_icon}  alt={"notification-icone"}></img>
                </button>
                {
                    this.state.showNotifVolet ? (
                        <div className="notif-volet">
                            <p>Notification 1</p>
                            <p>Notification 2</p>
                            <p>Notification 3</p>
                        </div>
                    ) : null
                }
            </div>
        )
    }
}

export default NotificationBase