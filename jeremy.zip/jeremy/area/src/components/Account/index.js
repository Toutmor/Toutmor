import React, { Component }  from 'react';

import { withRouter } from 'react-router-dom';
import PasswordChangeForm from '../PasswordChange';
import * as ROUTES from '../../constants/routes';
import { withGlobalState } from 'react-globally'
import { compose } from 'recompose';

import "./account.css"

const AccountPage = () => (
  <Account/>
);

class AccountBase extends Component {
  componentDidMount() {
    if (!this.props.globalState.user || this.props.globalState.user.message)
      this.props.history.push(ROUTES.SIGN_IN);
  }

  render() {
    const {user} = this.props.globalState;
    return (
      <div>
        {
          user ? (
            <div className="account">
              <h1>Account: {user.emailAdress}</h1>
              <PasswordChangeForm />
            </div>
          ): null
        }
      </div>
    );
  }
};

const Account = compose(
  withGlobalState,
  withRouter,
  )(AccountBase);

export { Account }

export default AccountPage;
