import React from 'react';
import { Link } from 'react-router-dom';

import SignOutButton from '../SignOut';
import * as ROUTES from '../../constants/routes';

import { AuthUserContext } from '../Session';

import './Navigation.css'

const Navigation = () => (
  <div>
    <AuthUserContext.Consumer>
      {authUser =>
        authUser ? <NavigationAuth /> : <NavigationAuth />
      }
    </AuthUserContext.Consumer>
  </div>
);

const NavigationAuth = () => (
  <div className="container-fluid navigation-bar">
    <div className="website-logo">
      <div className="logo logo-area">
          <img alt="logo" className="logo-size"/>
      </div>
    </div>
    <ul>
      <li className="workflows">
          <Link to={ROUTES.MYAPP}>Mes Applications</Link>
      </li>
      <li className="profil">
          <Link to={ROUTES.ACCOUNT}>Mon Profil</Link>
      </li>
      <li>
        <SignOutButton />
      </li>
    </ul>
  </div>

);

const NavigationNonAuth = () => (
  <p>
    
  </p>
);

/*
<li className="team">
  <Link to={ROUTES.TEAM}>Ma team</Link>
</li>
<li className="workflows">
  <Link to={ROUTES.WORKFLOWS}>Workflows</Link>
</li>
<ul>
  <li>
    <Link to={ROUTES.LANDING}>Landing</Link>
  </li>
  <li>
    <Link to={ROUTES.SIGN_IN}>Sign In</Link>
  </li>
</ul>
*/

export default Navigation;
