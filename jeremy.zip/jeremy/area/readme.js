headers: {'Authorization': 'Bearer ' + tokena},
        url: http://localhost:8080/users/${usera._id},
        method: 'PUT',
        body: usera,
        json: true



const express = require(express)
const bodyParser = require(body-parser)
const request = require(request)
var tokena;
var usera;
app = express()

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(express.static(__dirname + '/views'))
app.set(view engine, 'ejs')

app.post("/login", function(req, res){
    var newID = req.body.ID;
    var pass = req.body.PASS
    var jsonObject = {
        'username': newID,
        'password': pass
    }
    var options = {
        url: "http://localhost:8080/users/authenticate",
        method: 'POST',
        body: jsonObject,
        json: true
    }
    request(options, (error, res, body) => {
        if (error) {
          console.error(error)
          return
        }
        console.log(statusCode: ${res.statusCode})
        console.log(body is ${body} \nbody over)
        if (body) {
            /*token = body.token
            console.log(unique token is ${token})
            user = body.userWithoutHash
            console.log(user is ${user})
            var { body, ...bodyp } = body
            console.log(body is ${body})
            console.log(bodyp is ${bodyp})*/
            const { token, ...bodyWithoutToken } = body
            console.log(token is ${token} and rest is ${bodyWithoutToken.username})
            tokena = token
            usera = bodyWithoutToken
        }
      })
  });

app.post('/create', (req, res) => {
    var newID = req.body.ID;
    var pass = req.body.PASS
    var email = req.body.EMAIL
    var jsonObject = {
        'username': newID,
        'password': pass,
        'emailAdress': email,
        'firstName': req.body.FIRSTNAME,
        'lastName': req.body.LASTNAME
    }
    var options = {
        url: "http://localhost:8080/users/register",
        method: 'POST',
        body: jsonObject,
        json: true
    }
    request(options, (error, res, body) => {
        if (error) {
          console.error(error)
          return
        }
        console.log(statusCode: ${res.statusCode})
        console.log(body is ${body} \nbody over)
      })
})

app.post('/createAdmin', (req, res) => {
    var newID = req.body.ID;
    var pass = req.body.PASS
    var email = req.body.EMAIL
    var jsonObject = {
        'username': newID,
        'password': pass,
        'emailAdress': email,
        'firstName': req.body.FIRSTNAME,
        'lastName': req.body.LASTNAME,
        'roles': 'admin'
    }
    var options = {
        url: "http://localhost:8080/users/register",
        method: 'POST',
        body: jsonObject,
        json: true
    }
    request(options, (error, res, body) => {
        if (error) {
          console.error(error)
          return
        }
        console.log(statusCode: ${res.statusCode})
        console.log(body is ${body} \nbody over)
      })
})

app.get('/users', (req, res) => {
    var jsonObject = {
        'user_id': token
    }
    console.log(token about to be sent = ${token})
    var options = {
        headers: {'Authorization': 'Bearer ' + token},
        url: "http://localhost:8080/users",
        method: 'GET',
        body: jsonObject,
        json: true
    }
    request(options, (error, res, body) => {
        if (error) {
          console.error(error)
          return
        }
        console.log(statusCode: ${res.statusCode})
        console.log(body is ${body} \nbody over)
        const { ...test } = body
        console.log(test)
      })
})

app.get('/b', (req, res) => {
    usera.outlook = "eyJ0eXAiOiJKV1QiLCJub25jZSI6Im1hUmk2OF9SckZTcTlqbFBTY3I0Sk1QNmxTMm9YdnphRFo2VG9WdlZNY1kiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhsQzBSMTJza3hOWjFXUXdtak9GXzZ0X3RERSIsImtpZCI6IkhsQzBSMTJza3hOWjFXUXdtak9GXzZ0X3RERSJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC85MDFjYjRjYS1iODYyLTQwMjktOTMwNi1lNWNkMGY2ZDlmODYvIiwiaWF0IjoxNTgzMTkxNzkxLCJuYmYiOjE1ODMxOTE3OTEsImV4cCI6MTU4MzE5NTY5MSwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFTUUEyLzhPQUFBQWRjZEZtNnZqczBROTVTQ0RkbjgwT2FmbWs3c0d0UzgvekVDRmtsL1g4ZWM9IiwiYW1yIjpbInB3ZCJdLCJhcHBfZGlzcGxheW5hbWUiOiJ0ZXN0MSIsImFwcGlkIjoiYmE4ZjE0YzEtM2JhMy00Njc3LTkzMTQtMGVkMjA1Mzk1YTZkIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJXYWxsZXoiLCJnaXZlbl9uYW1lIjoiSsOpcsOpbXkiLCJpbl9jb3JwIjoidHJ1ZSIsImlwYWRkciI6IjkwLjczLjExMi4xNDEiLCJuYW1lIjoiSsOpcsOpbXkgV2FsbGV6Iiwib2lkIjoiZTg4YjBhMjMtOTU3My00OTc0LWJlMGQtODY1MzRmODNmMWJlIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTE1NTI0MzUyNzctMTU5NjQ5NTc5NS0zMDg5NjEzNzMxLTMxMTc1IiwicGxhdGYiOiIxNCIsInB1aWQiOiIxMDAzQkZGREEzRTQ5Q0MzIiwic2NwIjoiTWFpbC5SZWFkIG9wZW5pZCBwcm9maWxlIFVzZXIuUmVhZCBlbWFpbCIsInN1YiI6IlIwWUdWUWFiZkh2Z2dNcDJwcGhBOWt0dl93WFNvR2dYZ3FLNENNZWNDRFkiLCJ0aWQiOiI5MDFjYjRjYS1iODYyLTQwMjktOTMwNi1lNWNkMGY2ZDlmODYiLCJ1bmlxdWVfbmFtZSI6ImplcmVteS53YWxsZXpAZXBpdGVjaC5ldSIsInVwbiI6ImplcmVteS53YWxsZXpAZXBpdGVjaC5ldSIsInV0aSI6IkRMZWI1cmZEVDBHTUJaT0IzdWs2QUEiLCJ2ZXIiOiIxLjAiLCJ4bXNfc3QiOnsic3ViIjoiVlZwYl80R3FuN1UtSUtBRVE5a0daLThQU1o0SjBCQ2ZkM0tCb1RXNXJhUSJ9LCJ4bXNfdGNkdCI6MTQxNzgwNDg4N30.Kw01Ih4rs3cqRv1RHju4jgzPaQPjJP1wx4m2v1njh7kjKnSxxvrOaJLehG-p7WoUhFYuczHDYPBGYhQS28ypeZC80dPazFaYrOT_QQeA6Jl5pGQBNX0uf-OVVanq_crWC2KK4aXurfANbJw2SnJW44a-8hrLQCGuRbFsBVI_yfmP8GGf0B2Fn1L4biLL3xdsdw71s9HOh_9LqXgUFgiXEHPA8jX-57PC-_G6tAHBtqguoeUj4FjYAjSNvX4wSnISoO-a8zIEbr8L2Pzh5pA0K5oB1SIQnkjjhj7U6xU1mlxeiYZOo-osU74wc_u1AZYVwTWks5ShJFbchg5xnkmVrQ"
    var options = {
        headers: {'Authorization': 'Bearer ' + tokena},
        url: http://localhost:8080/users/${usera._id},
        method: 'PUT',
        body: usera,
        json: true
    }
    request(options, (error, res, body) => {
        if (error) {
          console.error(error)
          return
        }
        console.log(statusCode: ${res.statusCode})
        console.log(body is ${body} \nbody over)
        const { ...test } = body
        console.log(test)
      })
})

app.get('/c', (req, res) => {
    const options = {
        headers: {'Authorization': 'Bearer ' + tokena},
        url: http://localhost:8080/services/outlook/${usera._id},
        method: 'GET',
    }
    request(options, (error, res, body) => {
        if (error) {
            console.error(error)
            return
        }
        console.log(statusCode: ${res.statusCode})
    })
})

app.get('/auth', (req, res) => {
    /*var jsonObject = {
        'user_id': token
    }
    console.log(token about to be sent = ${token})*/
    var options = {
        url: "http://localhost:8080/auth/outlook",
        method: 'GET'
        /*body: jsonObject,
        json: true*/
    }
    request(options, (error, res, body) => {
        if (error) {
          console.error(error)
          return
        }
        console.log(statusCode: ${res.statusCode})
        console.log(body is ${body} \nbody over)
        const { ...test } = body
        //console.log(test)
        console.log(body)
    })
})

app.get('/')

app.get('/', (req, res) => {
    res.render(test.ejs)
})

app.get('/create', (req, res) => {
    res.render('create.ejs')
})

app.get('/createAdmin', (req, res) => {
    res.render('createAdmin.ejs')
})

app.get('/auth', (req, res) => {
    res.render(auth.ejs)
})

/*app.get(/users, (req, res) => {
    res.render('users.ejs')
})*/

app.listen(8080)